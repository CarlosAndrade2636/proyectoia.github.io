/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ec.edu.ups.modelo;

/**
 *
 * @author Karlitox
 */
public class VecinosSimilares {
    private String vecino1;
    private String vecino2;
    private double similitud;

    public String getVecino1() {
        return vecino1;
    }

    public void setVecino1(String vecino1) {
        this.vecino1 = vecino1;
    }

    public String getVecino2() {
        return vecino2;
    }

    public void setVecino2(String vecino2) {
        this.vecino2 = vecino2;
    }

    public double getSimilitud() {
        return similitud;
    }

    public void setSimilitud(double similitud) {
        this.similitud = similitud;
    }
    
    
    
}
