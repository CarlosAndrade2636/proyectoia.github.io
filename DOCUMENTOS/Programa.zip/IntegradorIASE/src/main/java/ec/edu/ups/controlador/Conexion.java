package ec.edu.ups.controlador;

import ec.edu.ups.modelo.Ciudad;
import ec.edu.ups.modelo.Dato;
import ec.edu.ups.modelo.Lugar;
import ec.edu.ups.modelo.Nodo;
import ec.edu.ups.modelo.Vecino;
import ec.edu.ups.modelo.VecinosSimilares;
import java.util.ArrayList;
import java.util.List;
import org.neo4j.driver.AuthTokens;
import org.neo4j.driver.Driver;
import org.neo4j.driver.GraphDatabase;
import org.neo4j.driver.Record;
import org.neo4j.driver.Session;
import org.neo4j.driver.Result;
import org.neo4j.driver.Transaction;
import org.neo4j.driver.TransactionWork;
import org.neo4j.driver.Values;
import static org.neo4j.driver.Values.parameters;

/**
 *
 * @author Karlitox
 */
public class Conexion implements AutoCloseable {

    private Driver driver;

    @Override
    public void close() throws Exception {
        driver.close();
    }

    public void Conectar() {
        try {
            String uri = "bolt://localhost:7687";
            String user = "neo4j";
            String password = "PTNXxqjq1820";
            driver = GraphDatabase.driver(uri, AuthTokens.basic(user, password));
        } catch (Exception e) {

        }
    }

    public List<Ciudad> baseNoe4j() {
        try (Session session = driver.session()) {
            List<Ciudad> vec = new ArrayList<>();
            String coneccionNeo4j = session.writeTransaction((Transaction tx) -> {
               Result result = tx.run("MATCH (c:Parque)-[dis:DISTANCIA]->(d:Parque) return c.name as ini, d.name as fin ,dis.weight as costo");
              
              for (Record record : result.list()) {
                    String nomi = record.get("ini").asString();
                   String nomf = record.get("fin").asString();
                   Double costo = record.get("costo").asDouble();
                    Ciudad c = new Ciudad(nomi, nomf, costo);
                    vec.add(c);
                }
                return null;
            });
            return vec;
        }
    }

  
     public List<Dato> PageRank(String lugar) {
        List<Dato> list = new ArrayList<>();
        try (Session session = driver.session()) {
            String coneccionNeo4j = session.writeTransaction(new TransactionWork<String>() {
                @Override
                public String execute(Transaction tx) {
                    Result res = tx.run("CALL gds.pageRank.stream('"+lugar+"', { maxIterations: 30, dampingFactor: 0.85 }) YIELD nodeId, score RETURN gds.util.asNode(nodeId).name AS name, score ORDER BY score ASC");
                    for (Record r : res.list()) {
                        Dato dato = new Dato();
                        dato.setNombre(r.get(0).asString());
                        dato.setCentralidad(r.get("score").asDouble());
                        //dato.setCentralidad(0.0);
                        list.add(dato);

                    }
                    return null;
                }
            });
        }
        return list;
    }
     
 

    public List<Dato> componentesFuertes(String tipo , String ciudad ) {
        List<Dato> list = new ArrayList<>();
        try (Session session = driver.session()) {
            String coneccionNeo4j = session.writeTransaction(new TransactionWork<String>() {
                @Override
                public String execute(Transaction tx) {
                    Result res = tx.run("CALL gds.alpha.scc.stream({ nodeQuery: 'MATCH (u:"+tipo+") where u.Ciudad= '"+ciudad
                            + "' RETURN id(u)  AS id', relationshipQuery: 'MATCH (u1:"+tipo+")-[:DISTANCIA]->(u2:"+tipo+") "
                            + "where u1.Ciudad='"+ciudad+"' AND u2.Ciudad='"+ciudad+"' RETURN id(u1) AS source, id(u2) AS target' })"
                            + " YIELD nodeId, componentId "
                            + "RETURN gds.util.asNode(nodeId).name AS Name, componentId AS Component ORDER BY Component DESC  ");
                    for (Record r : res.list()) {
                        Dato p = new Dato();
                        p.setNombre(r.get(0).asString());
                        p.setCentralidad(r.get("communityId").asDouble());
                        list.add(p);
                    }
                    return null;
                }
            });
         
        }

        return list;
    }



 
 public List<Nodo> rutaRecomendadaNueva(String inicio, String fin,String tipo) {
      
        try (Session session = driver.session()) {
            List<Nodo> vec = new ArrayList<>();
            String coneccionNeo4j = session.writeTransaction((Transaction tx) -> {
                Result result = tx.run(
                        "MATCH (start:$tipo {name: '" + inicio + "'}), (end:$tipo{name: '" + fin + "'}) "
                        + "CALL gds.alpha.shortestPath.stream({ "
                        + "nodeProjection: $tipo, "
                        + "relationshipProjection: { "
                        + "LINK: {type: 'LINK',properties: 'cost'}}, "
                        + "startNode: start, "
                        + "endNode: end, "
                        + "relationshipWeightProperty: 'cost' "
                        + "}) "
                        + "YIELD nodeId, cost "
                        + "RETURN gds.util.asNode(nodeId).name AS name, cost ",Values.parameters("origen", inicio, "destino", fin, "clase", tipo));
                for (Record record : result.list()) {
                    String nomi = record.get("name").asString();
                    Double costo = 0.00;
                    Nodo ns = new Nodo(nomi, costo);
                    vec.add(ns);
                }
                return null;
            });
            return vec;
        }
    }

    
      public List<Lugar> busquedaGustosP(String clase, String origen) {
        List<Lugar> list = new ArrayList<>();
        try (Session session = driver.session()) {
            String coneccionNeo4j = session.writeTransaction(new TransactionWork<String>() {
                @Override
                public String execute(Transaction tx) {
                    
                     Result res = tx.run("MATCH (c:Persona{name:'"+origen+"'})-[dis:LIKES]->(d:"+clase+")  RETURN gds.alpha.linkprediction.resourceAllocation(c, d) AS costo, c.name as ini , d.name as fin ", Values.parameters("origen", origen , "clase", clase));
                    for (Record r : res.list()) {
                        Lugar p = new Lugar();
                        System.out.println("RUTA" + r.get("ruta"));
                        p.setCosto(r.get(0).asDouble());
                        p.setNombre(r.get(2).asString());
                      
                        
                        list.add(p);
                    }
                    return null;
                }
            });
       
        }
        return list;

    }

    public List<Lugar> busquedaAmplitud2(String clase, String origen, String destino) {
        List<Lugar> list = new ArrayList<>();
        try (Session session = driver.session()) {
            String coneccionNeo4j = session.writeTransaction(new TransactionWork<String>() {
                @Override
                public String execute(Transaction tx) {
                    Result res = tx.run("MATCH (a:Parque{name:$origen}),(e:Parque{name:$destino}) "
                            + "WITH id(a) AS origen, [id(e)] AS destino "
                            + "CALL gds.alpha.bfs.stream($clase, {startNode: origen, targetNodes: destino}) "
                            + "YIELD path "
                            + "UNWIND [ n in nodes(path) | n.name ] AS ruta "
                            + "RETURN ruta ORDER BY ruta ", Values.parameters("origen", origen, "destino", destino, "clase", clase));
                 
                    for (Record r : res.list()) {
                        Lugar p = new Lugar();
                        System.out.println("RUTA" + r.get("ruta"));
                        p.setNombre(r.get(0).asString());
                   
                        list.add(p);
                    }
                    return null;
                }
            });
            
        }
        return list;

    }

 

    public List<Lugar> listar(String param) {
        System.out.println(param);
        String query = "MATCH(n:" + param + ")return n.name";
        List<Lugar> list = new ArrayList<>();
        try (Session session = driver.session()) {
            String greeting = session.writeTransaction(new TransactionWork<String>() {
                @Override
                public String execute(Transaction tx) {
                    System.out.println("VIENE CON " + param);
                    Result result = tx.run(query + " as nombre");
                    for (Record r : result.list()) {
                    
                        Lugar lugar = new Lugar();
                        
                        lugar.setNombre(r.get("nombre").asString());
                       
                        list.add(lugar);
                       

                    }
                    return null;
                }
            });
         
        }
        return list;
    }
     public List<Lugar> listarP() {
        
        String query = "MATCH(n:Persona)return n.name";
        List<Lugar> list = new ArrayList<>();
        try (Session session = driver.session()) {
            String greeting = session.writeTransaction(new TransactionWork<String>() {
                @Override
                public String execute(Transaction tx) {
                    Result result = tx.run(query + " as nombre");
                    for (Record r : result.list()) {
                        Lugar lugar = new Lugar();
                        lugar.setNombre(r.get("nombre").asString());
                        list.add(lugar);

                    }
                    return null;
                }
            });
          
        }
        return list;
    }


    public void insertPerson(String nombrePersona, int id) {
        try (Session session = driver.session()) {
            String greeting = session.writeTransaction(new TransactionWork<String>() {
                @Override
                public String execute(Transaction tx) {
                    Result res = tx.run("CREATE (:Persona{ id: '" + id + "', name:'" + nombrePersona + "'})");
                    return null;
                }

            });
        }
    }

   

    public List<Vecino> listarVecino(String param) {
        List<Vecino> list = new ArrayList<>();
        try (Session session = driver.session()) {
            String greeting = session.writeTransaction(new TransactionWork<String>() {
                @Override
                public String execute(Transaction tx) {
                    Result result = tx.run("MATCH(n:" + param + ") return n.name AS m");
                    for (Record r : result.list()) {
                        ///Relaciones l = new Relaciones();
                        Vecino vecino = new Vecino();
                        vecino.setNombre(r.get(0).asString());
                        list.add(vecino);
                    }
                    return null;
                }
            });
          
        }
        return list;

    }

   
    public void nuevaR(String nombrePersona, String nombreLugar, String tipo) {

        try (Session session = driver.session()) {
            String greeting = session.writeTransaction(new TransactionWork<String>() {
                @Override
                public String execute(Transaction tx) {
                    Result res = tx.run("MATCH (ini:Persona{name:'" + nombrePersona + "'}),(des:" + tipo + "{name:'" + nombreLugar + "'}) CREATE (ini)-[:LIKES]->(des); ");
                    return null;
                }
               
            });
            
        }

    }

    public List<VecinosSimilares> similitudJaccard() {

        List<VecinosSimilares> list = new ArrayList<>();
        try (Session session = driver.session()) {
            String greeting = session.writeTransaction(new TransactionWork<String>() {
                @Override
                public String execute(Transaction tx) {
                    Result result = tx.run("MATCH (p:Persona)-[:LIKES]->(lugarturistico) "
                            + " WITH {item:id(p), categories: collect(id(lugarturistico))} AS userData "
                            + " WITH collect(userData) AS data "
                            + " CALL gds.alpha.ml.ann.stream({ "
                            + "   nodeProjection: '*',"
                            + "   relationshipProjection: '*',"
                            + "   data: data, "
                            + "   algorithm: 'jaccard', "
                            + "   similarityCutoff: 0.1, "
                            + "   concurrency: 1 "
                            + " }) "
                            + " YIELD item1, item2, similarity "
                            + " return gds.util.asNode(item1).name AS from, gds.util.asNode(item2).name AS to, similarity "
                            + " ORDER BY from");
                    for (Record r : result.list()) {
                        VecinosSimilares p = new VecinosSimilares();
                        p.setVecino1(r.get("from").asString());
                        p.setVecino2(r.get("to").asString());
                        p.setSimilitud(r.get("similarity").asDouble());
                        list.add(p);
                    }
                    return null;
                }
            });
        }
        return list;

    }
    
    public List<VecinosSimilares> procesarDatos() {

        List<VecinosSimilares> list = new ArrayList<>();
        try (Session session = driver.session()) {
            String greeting = session.writeTransaction(new TransactionWork<String>() {
                @Override
                public String execute(Transaction tx) {
                    Result result = tx.run("MATCH (p:Persona)-[:LIKES]->(Escuela) "
                            + " WITH {item:id(p), categories: collect(id(escuela))} AS userData "
                            + " WITH collect(userData) AS data "
                            + " CALL gds.alpha.ml.ann.stream({ "
                            + "   nodeProjection: '*', "
                            + "   relationshipProjection: '*',"
                            + "   data: data, "
                            + "   algorithm: 'jaccard', "
                            + "   similarityCutoff: 0.1, "
                            + "   concurrency: 1 "
                            + " }) "
                            + " YIELD item1, item2, similarity "
                            + " return gds.util.asNode(item1).name AS from, gds.util.asNode(item2).name AS to, similarity "
                            + " ORDER BY from");
                    for (Record r : result.list()) {
                        VecinosSimilares p = new VecinosSimilares();
                        p.setVecino1(r.get("from").asString());
                        p.setVecino2(r.get("to").asString());
                        p.setSimilitud(r.get("similarity").asDouble());
                        list.add(p);
                    }
                    return null;
                }
            });
        }
        return list;

    }
    

}
