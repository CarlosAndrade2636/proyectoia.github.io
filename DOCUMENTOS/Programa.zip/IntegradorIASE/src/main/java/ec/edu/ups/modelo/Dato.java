/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ec.edu.ups.modelo;

/**
 *
 * @author Karlitox
 */
public class Dato implements Comparable<Dato>{
    public String nombre;
    public double centralidad;

    public Dato() {
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public double getCentralidad() {
        return centralidad;
    }

    public void setCentralidad(double centralidad) {
        this.centralidad = centralidad;
    }

    @Override
    public int compareTo(Dato t) {
        if (centralidad < t.centralidad) {
                return -1;
            }
            if (centralidad > t.centralidad) {
                return 1;
            }
            return 0;
    }
  
}
