/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ec.edu.ups.modelo;

/**
 *
 * @author Karlitox
 */
public class Relaciones {
    public String cior;
    public String cidst;
    public Double cost;

    public Relaciones() {
    }

    public String getCior() {
        return cior;
    }

    public void setCior(String cior) {
        this.cior = cior;
    }

    public String getCidst() {
        return cidst;
    }

    public void setCidst(String cidst) {
        this.cidst = cidst;
    }

    public Double getCost() {
        return cost;
    }

    public void setCost(Double cost) {
        this.cost = cost;
    }

    @Override
    public String toString() {
        return "Relaciones{" + "cior=" + cior + ", cidst=" + cidst + ", cost=" + cost + '}';
    }
    
    
}
