/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ec.edu.ups.vista;

import ec.edu.ups.controlador.Conexion;
import ec.edu.ups.modelo.Dato;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JDesktopPane;
import javax.swing.JPanel;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Karlitox
 */
public class PageRank extends javax.swing.JInternalFrame {

    JDesktopPane pane;
    public String seleccion;
    public String lugardestino;
    private Conexion conexion; 
            
    public PageRank() {
        initComponents();
        
    }

   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        cbxlugares = new javax.swing.JComboBox<>();
        jScrollPane1 = new javax.swing.JScrollPane();
        resultado = new javax.swing.JTable();

        setClosable(true);

        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "LUGARES MAS POPULARES", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 3, 24))); // NOI18N
        jPanel1.setName("top 10 lugares mas visitados\n"); // NOI18N

        jLabel1.setText("Seleccione un Lugar:");

        cbxlugares.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Lugar", "Parques", "Colegios", "Mercados", "Iglesias", "Hospitales" }));
        cbxlugares.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbxlugaresActionPerformed(evt);
            }
        });

        resultado.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null},
                {null, null},
                {null, null},
                {null, null}
            },
            new String [] {
                "Nombre", "score"
            }
        ));
        jScrollPane1.setViewportView(resultado);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(27, 27, 27)
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(cbxlugares, javax.swing.GroupLayout.PREFERRED_SIZE, 324, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(49, 49, 49)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 673, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(108, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(36, 36, 36)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cbxlugares, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(26, 26, 26)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 310, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(51, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        jPanel1.getAccessibleContext().setAccessibleName("top 10 lugares mas visitado de ");

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void cbxlugaresActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbxlugaresActionPerformed
       
        String p = (String) cbxlugares.getSelectedItem();
        if (p.equalsIgnoreCase("Hospitales")) {
            seleccion = "Escuela";
           Conexion c = new Conexion();
           c.Conectar();
           List<Dato> par = c.PageRank("Hospital");
         
            System.out.println(" cantidad"+ par.size());
            
        
        
            String matris[] [] = new String[par.size()][2];
            
            for (int i = 0; i < par.size(); i++) {
             matris[i][0]= par.get(i).getNombre();
             matris[i][1]= String.valueOf(par.get(i).getCentralidad());
            }
            resultado.setModel(new javax.swing.table.DefaultTableModel(
           matris,
            new String [] {
                "Nombre", "score"
            }
        ));
        } else if (p.equalsIgnoreCase("Parques")) {
            seleccion = "Estimacion";
           
            Conexion c = new Conexion();
            c.Conectar();
            List<Dato> par = c.PageRank("Parque");
        
            
            System.out.println(" cantidad"+ par.size());
            
        
        
            String matris[] [] = new String[par.size()][2];
            
            for (int i = 0; i < par.size(); i++) {
             matris[i][0]= par.get(i).getNombre();
             matris[i][1]= String.valueOf(par.get(i).getCentralidad());
            }
            resultado.setModel(new javax.swing.table.DefaultTableModel(
           matris,
            new String [] {
                "Nombre", "score"
            }
        ));
            

        }else if (p.equalsIgnoreCase("Colegios")) {
            seleccion = "Estimacion";
           
            Conexion c = new Conexion();
            c.Conectar();
            List<Dato> par = c.PageRank("Colegio");
           
            
            System.out.println(" cantidad"+ par.size());
            
        
        
            String matris[] [] = new String[par.size()][2];
            
            for (int i = 0; i < par.size(); i++) {
             matris[i][0]= par.get(i).getNombre();
             matris[i][1]= String.valueOf(par.get(i).getCentralidad());
            }
            resultado.setModel(new javax.swing.table.DefaultTableModel(
           matris,
            new String [] {
                "Nombre", "score"
            }
        ));
            

        }else if (p.equalsIgnoreCase("Mercados")) {
            seleccion = "Estimacion";
           
            Conexion c = new Conexion();
            c.Conectar();
            List<Dato> par = c.PageRank("Mercado");
           
            
            System.out.println(" cantidad"+ par.size());
            
        
        
            String matris[] [] = new String[par.size()][2];
            
            for (int i = 0; i < par.size(); i++) {
             matris[i][0]= par.get(i).getNombre();
             matris[i][1]= String.valueOf(par.get(i).getCentralidad());
            }
            resultado.setModel(new javax.swing.table.DefaultTableModel(
           matris,
            new String [] {
                "Nombre", "score"
            }
        ));
            

        }else if (p.equalsIgnoreCase("Iglesias")) {
            seleccion = "Estimacion";
           
            Conexion c = new Conexion();
            c.Conectar();
            List<Dato> par = c.PageRank("Iglesia");
          
            System.out.println(" cantidad"+ par.size());
            
        
        
            String matris[] [] = new String[par.size()][2];
            
            for (int i = 0; i < par.size(); i++) {
             matris[i][0]= par.get(i).getNombre();
             matris[i][1]= String.valueOf(par.get(i).getCentralidad());
            }
            resultado.setModel(new javax.swing.table.DefaultTableModel(
           matris,
            new String [] {
                "Nombre", "score"
            }
        ));
            

        }
    }//GEN-LAST:event_cbxlugaresActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> cbxlugares;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable resultado;
    // End of variables declaration//GEN-END:variables
}
